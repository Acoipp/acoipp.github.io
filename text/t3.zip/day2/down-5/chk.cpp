#include "testlib.h"
#include <bits/stdc++.h>
using namespace std;

int main (int argc,char* argv[]) {
	registerTestlibCmd(argc,argv);
	int cnt=ouf.readInt(),hard=ouf.readInt();
	double avg=(double)cnt/600.0;
	if (hard==0) {
		if (avg>6.0) {quitf(_wa,"%.3f queries in average\n",avg);}
		else if (avg>4.4) {quitp(0.25*(6.0-avg),"%.3f queries in average\n",avg);}
		else if (avg>3.6) {quitp(0.4+0.5*(4.4-avg),"%.3f queries in average\n",avg);}
		else if (avg>3.5) {quitp(0.8+2.0*(3.6-avg),"%.3f queries in average\n",avg);}
		else {quitf(_ok,"%.3f queries in average\n",avg);}
	} else {
		if (avg>6.0) {quitf(_wa,"%.3f queries in average\n",avg);}
		else if (avg>4.4) {quitp(0.25*(6.0-avg),"%.3f queries in average\n",avg);}
		else if (avg>3.8) {quitp(0.4+2.0*(4.4-avg)/3.0,"%.3f queries in average\n",avg);}
		else if (avg>3.6) {quitp(0.8+(3.8-avg),"%.3f queries in average\n",avg);}
		else {quitf(_ok,"%.3f queries in average\n",avg);}
	}
	return 0;
}

