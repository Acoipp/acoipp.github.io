#include<bits/stdc++.h>
#pragma GCC optimize("Ofast")
#define ll long long
#define N 500005
using namespace std;
vector<ll> ope[N<<1],cntt[N];
ll n,m,i,j,k,p,qzh[N*10],ans[N],trie[N<<1][26],tot,fail[N<<1],cnt[N<<1],idd[N*10],l[N],r[N],len[N<<1],tr[(N*10)<<2],a[N*10],id[N<<1];
string s[N],t;
queue<ll> op;
inline void insert(string s,ll idd){
	ll p = 0;
	for(ll i=0;i<s.size();i++){
		if(!trie[p][s[i]-'a']) trie[p][s[i]-'a']=++tot;
		p = trie[p][s[i]-'a'];
	}
	cnt[p]++,len[p]=s.size(),id[p]=idd;
}
inline void dfs(ll x){
	for(ll i=0;i<ope[x].size();i++){
		if(len[x]>len[ope[x][i]]) len[ope[x][i]]=len[x],id[ope[x][i]]=id[x];
		cnt[ope[x][i]]+=cnt[x],dfs(ope[x][i]);
	}
}
inline void build(){
	for(ll i=0;i<26;i++) if(trie[0][i]) op.push(trie[0][i]);
	while(op.size()){
		ll tmp = op.front();
		op.pop();
		for(ll i=0;i<26;i++){
			if(trie[tmp][i]) fail[trie[tmp][i]]=trie[fail[tmp]][i],op.push(trie[tmp][i]);
			else trie[tmp][i]=trie[fail[tmp]][i];
		} 
	}
	for(ll i=1;i<=tot;i++) ope[fail[i]].push_back(i);
	dfs(0);
}
inline void clear(){
	for(ll i=0;i<=tot;i++){
		fail[i]=0,cnt[i]=0,ope[i].clear(),len[i]=0,id[i]=0;
		for(ll j=0;j<26;j++) trie[i][j]=0;
	}
	tot=0;
}
inline void build(ll s,ll t,ll p){
	if(s==t){
		tr[p] = a[s];
		return ;
	}
	build(s,(s+t)/2,2*p),build((s+t)/2+1,t,2*p+1);
	tr[p] = min(tr[2*p],tr[2*p+1]);
}
inline ll query(ll l,ll r,ll s,ll t,ll p){
	if(l<=s&&t<=r){
		if(tr[p]>=l) return -1;
		if(s==t) return s;
		if(tr[2*p+1]<l) return query(l,r,(s+t)/2+1,t,2*p+1);
		else return query(l,r,s,(s+t)/2,2*p);
	}
	ll ans = -1;
	if(r>(s+t)/2) ans=query(l,r,(s+t)/2+1,t,2*p+1);
	if(ans!=-1) return ans;
	if(l<=(s+t)/2) return query(l,r,s,(s+t)/2,2*p);
	else return -1;
}
int main(){
//	freopen("1.in","r",stdin);
//	freopen("1.out","w",stdout);
	ios::sync_with_stdio(false);
	cin>>n>>m>>t;
	for(i=1;i<=n;i++) cin>>s[i];
	for(i=1;i<=m;i++) cin>>l[i]>>r[i];
	for(i=1;i<=n;i++) insert(s[i],i);
	build();
	for(i=1,p=0;i<=t.size();i++) p=trie[p][t[i-1]-'a'],qzh[i]=qzh[i-1]+cnt[p],a[i]=i-len[p]+1,idd[i]=id[p];
	build(1,t.size(),1);
	clear();
	for(i=1;i<=n;i++){
		reverse(s[i].begin(),s[i].end());
		insert(s[i],i);
	}
	build();
	for(i=1;i<=n;i++){
		cntt[i].push_back(0);
		for(j=0,p=0;j<s[i].size();j++){
			p = trie[p][s[i][j]-'a'];
			cntt[i].push_back(cntt[i][j]+cnt[p]);
		}
	}
	for(i=1;i<=m;i++){
		ll pos = query(l[i],r[i],1,t.size(),1);
		if(pos==-1){
			ans[i] = qzh[r[i]]-qzh[l[i]-1];
			continue;
		}
		ans[i] = qzh[r[i]]-qzh[pos]+cntt[idd[pos]][pos-l[i]+1];
	}
	for(i=1;i<=m;i++) cout<<ans[i]<<" ";
	return 0;
}
