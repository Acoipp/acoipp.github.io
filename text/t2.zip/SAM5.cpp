#include<bits/stdc++.h>
#define ll long long
#define N 400005
using namespace std;
struct node{ll l,r,id;}p[N];
char s1[N],s2[N],t[N];
vector<pair<ll,ll> > op[N]; 
ll n,m,q,i,j,k,ans[N],sam[N][27],fath[N],len[N],root=1,now=1,tot=1,all,K,son[N],ne[N],to[N],la[N],et,cnt[N],id[N],ls[N],rs[N];
ll qzh[N],st[N][21],idt[N];
inline void merge(ll x,ll y){et++,ne[et]=la[x],la[x]=et,to[et]=y;}
inline bool cmp(node a,node b){return id[a.l]<id[b.l];}
inline void insert(ll x){
	ll p = now;now = ++tot,len[now] = len[p]+1;
	while(p&&!sam[p][x]) sam[p][x]=now,p=fath[p];
	if(!p) fath[now]=root;
	else{
		ll q = sam[p][x];
		if(len[p]+1==len[q]) fath[now]=q;
		else{
			ll temp = ++tot;
			len[temp] = len[p]+1,fath[temp] = fath[q];
			for(ll i=0;i<27;i++) sam[temp][i]=sam[q][i];
			fath[now] = fath[q] = temp;
			while(sam[p][x]==q) sam[p][x]=temp,p=fath[p];
		}
	}
}
inline void clear(){
	for(ll i=1;i<=tot;i++){
		fath[i] = len[i] = 0,son[i] = 0,la[i] = 0,cnt[i] = 0;
		for(ll j=0;j<27;j++) sam[i][j]=0;
	}
	root=1,now=1,tot=1;
	while(et) ne[et]=to[et]=0,et--;
}
inline void dfs(ll x){for(ll i=la[x];i;i=ne[i]) dfs(to[i]),son[x]+=son[to[i]];cnt[x]=son[x]*len[x];}
inline void dfs2(ll x){for(ll i=la[x];i;i=ne[i]) cnt[to[i]]=max(cnt[to[i]],cnt[x]),dfs2(to[i]);}
inline void dfs3(ll x){
	for(ll i=1;i<=20;i++) st[x][i]=st[st[x][i-1]][i-1];
	for(ll i=la[x];i;i=ne[i]) st[to[i]][0]=x,dfs3(to[i]),son[x]+=son[to[i]];
	cnt[x]=son[x]*len[x];
}
inline void dfs4(ll x){
	for(ll i=0;i<op[x].size();i++) ans[op[x][i].first]=max(ans[op[x][i].first],max(op[x][i].second*son[x],cnt[fath[x]]));
	for(ll i=la[x];i;i=ne[i]){
		cnt[to[i]]=max(cnt[to[i]],cnt[x]);
		dfs4(to[i]);
	}
}
int main(){
	ios::sync_with_stdio(false);
	cin>>(s1+1)>>(s2+1)>>q,n=strlen(s1+1),m=strlen(s2+1),K=sqrt(n);
	for(i=1;i<=n;i++) t[++all]=s1[i];
	t[++all]='z'+1;
	for(i=1;i<=m;i++) t[++all]=s2[i];
	for(i=1;i<=all;i++){
		insert(t[i]-'a');
		if(i>n+1) son[now]++;
	}
	for(i=2;i<=tot;i++) merge(fath[i],i);
	dfs(1),dfs2(1);
	for(i=1;i<=q;i++){
		cin>>p[i].l>>p[i].r,p[i].id=i;
		if(p[i].r-p[i].l+1<=K){
			ll pos = root;
			for(j=p[i].l;j<=p[i].r;j++){
				pos = sam[pos][s1[j]-'a'];
				ans[i] = max(ans[i],max(cnt[fath[pos]],son[pos]*(j-p[i].l+1)));
			}
		}
	}
	for(i=1;i<=n;i++){
		id[i]=(i-1)/K+1;
		if(!ls[id[i]]) ls[id[i]]=i;
		rs[id[i]]=i;
	}
	sort(p+1,p+q+1,cmp);
	for(i=1;i<=q;){
		if(p[i].r-p[i].l+1<=K){
			i++;
			continue;
		}
		for(j=i;j<=q;j++) if(id[p[i].l]!=id[p[j].l]) break;
		ll pos = root;
		for(k=ls[id[p[i].l]+1];k<=n;k++) pos=sam[pos][s1[k]-'a'],qzh[k]=max(qzh[k-1],max(cnt[fath[pos]],son[pos]*(k-ls[id[p[i].l]+1]+1)));
		for(k=i;k<j;k++) ans[p[k].id]=max(ans[p[k].id],qzh[p[k].r]);
		for(k=ls[id[p[i].l]+1];k<=n;k++) qzh[k]=0;
		i=j;
	}
	clear();
	for(i=all;i>=1;i--){
		insert(t[i]-'a'),idt[i] = now;
		if(i>n+1) son[now]++;
	}
	for(i=2;i<=tot;i++) merge(fath[i],i);
	dfs3(1);
	for(i=1;i<=q;i++){
		if(p[i].r-p[i].l+1<=K) continue;
		ll l = ls[id[p[i].l]+1],r = p[i].r;
		ll pos = idt[l];
		for(j=20;j>=0;j--) if(st[pos][j]&&len[fath[st[pos][j]]]>=r-l+1) pos=st[pos][j];
		if(len[fath[pos]]>=r-l+1) pos=fath[pos];
		for(j=l-1;j>=p[i].l;j--) pos=sam[pos][s1[j]-'a'],op[pos].push_back(make_pair(p[i].id,p[i].r-j+1));
	}
	dfs4(1);
	for(i=1;i<=q;i++) cout<<ans[i]<<endl;
	return 0;
}
