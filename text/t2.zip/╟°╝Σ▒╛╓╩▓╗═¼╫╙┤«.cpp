#include<bits/stdc++.h>
#define get(x) (tr[tr[x].fa].ch[1]==x)
#define ll long long
#define N 200005
using namespace std;
struct node{ll ch[2],fa,p,la;}tr[N];
struct tree{ll x,tag;}trr[N<<2];
struct answer{ll l,r,id;}p[N];
inline void pushup(ll p){tr[p].p = (tr[p].ch[1]?tr[tr[p].ch[1]].p:p),tr[p].la = (tr[p].ch[0]?tr[tr[p].ch[0]].la:p);}
inline bool isroot(ll p){return tr[tr[p].fa].ch[0]!=p&&tr[tr[p].fa].ch[1]!=p;}
inline void upd(ll p){pushup(p);if(!isroot(p)) upd(tr[p].fa);}
inline void rotate(ll p){
	ll y=tr[p].fa,z=tr[y].fa,k=get(p);
	if(!isroot(y)) tr[z].ch[tr[z].ch[1]==y]=p;
	tr[y].ch[k]=tr[p].ch[!k],tr[tr[p].ch[!k]].fa=y,tr[p].ch[!k]=y,tr[y].fa=p,tr[p].fa=z;
	pushup(y),pushup(p);
}
inline void splay(ll p){
	upd(p);
	for(ll f;f=tr[p].fa,!isroot(p);rotate(p)) if(!isroot(f)) rotate(get(f)==get(p)?f:p);
}
ll n,nn,m,type,i,j,opt,x,y,z,temp,len[N],sam[N][26],fath[N],root=1,now=1,tot=1,tr_tot,ans[N],totet;
char s[N],ch;
inline void pushtag(ll p,ll c,ll s,ll t){trr[p].x += c*(t-s+1),trr[p].tag += c;}
inline void pushdown(ll p,ll s,ll t){pushtag(2*p,trr[p].tag,s,(s+t)/2),pushtag(2*p+1,trr[p].tag,(s+t)/2+1,t),trr[p].tag=0;}
inline void modify(ll l,ll r,ll c,ll s,ll t,ll p){
	if(l>r) return ;
	if(l<=s&&t<=r) return pushtag(p,c,s,t);
	pushdown(p,s,t);
	if(l<=(s+t)/2) modify(l,r,c,s,(s+t)/2,2*p);
	if(r>(s+t)/2) modify(l,r,c,(s+t)/2+1,t,2*p+1);
	trr[p].x = trr[2*p].x + trr[2*p+1].x;
}
struct nodee{ll p,q,a,b;}q[N<<5];
inline void add(ll p,ll qq,ll a,ll b){q[++totet]=(nodee){p,qq,a,b};}
inline void access(ll p){
	ll i;
//	add(0,n,n,n);
	for(i=0;p;i=p,p=tr[p].fa){
		splay(p);
		if(p!=1) add(len[tr[p].p],n,len[p],len[fath[tr[p].la]]+1);
		tr[p].ch[1]=i,pushup(p);
	}
}
inline void link(ll x,ll y){tr[y].p = y,tr[y].fa = x,access(y);}
inline void insert(ll x){
	ll p = now;now = ++tot,len[now] = len[p]+1;
	while(p&&!sam[p][x]) sam[p][x]=now,p=fath[p];
	if(!p) fath[now]=root,link(root,now);
	else{
		ll q = sam[p][x];
		if(len[p]+1==len[q]) fath[now]=q,link(q,now);
		else{
			ll temp = ++tot;
			for(ll i=0;i<26;i++) sam[temp][i]=sam[q][i];
			fath[temp] = fath[q];
			fath[now] = fath[q] = temp;			
			splay(q),len[temp] = len[p]+1,tr[tr[q].ch[0]].fa=temp,tr[temp].ch[0]=tr[q].ch[0],tr[temp].fa=q,tr[q].ch[0]=temp;
			pushup(temp),pushup(q),link(temp,now);
			while(sam[p][x]==q) sam[p][x]=temp,p=fath[p];
		}
	}
}
inline ll query(ll l,ll r,ll s,ll t,ll p){
	if(l<=s&&t<=r) return trr[p].x;
	pushdown(p,s,t);
	ll ans = 0;
	if(l<=(s+t)/2) ans+=query(l,r,s,(s+t)/2,2*p);
	if(r>(s+t)/2) ans+=query(l,r,(s+t)/2+1,t,2*p+1);
	return ans;
}
inline bool cmp(answer a,answer b){return a.r<b.r;}
inline bool cmp2(nodee a,nodee b){return a.q<b.q;}
int main(){
	ios::sync_with_stdio(false);
	cin>>(s+1)>>m,nn=strlen(s+1);
	for(i=1;i<=nn;i++) n++,insert(s[i]-'a');
	for(i=1;i<=m;i++) cin>>p[i].l>>p[i].r,p[i].id=i;
	sort(p+1,p+m+1,cmp);
	sort(q+1,q+totet+1,cmp2);
	for(i=1,j=1;i<=m;i++){
		while(j<=totet&&q[j].q<=p[i].r){
			if(q[j].q==q[j].p){
				modify(1,1,q[j].a-q[j].b+1,1,n,1);
				modify(q[j].p-q[j].a+2,q[j].p-q[j].b+2,-1,1,n,1);
			}
			else{
				modify(max(q[j].p-q[j].a+2,1ll),q[j].p-q[j].b+2,1,1,n,1);
				modify(max(q[j].q-q[j].a+2,1ll),q[j].q-q[j].b+2,-1,1,n,1);
			}
			j++;
		}
		ans[p[i].id] = query(1,p[i].l,1,n,1);
	}
	for(i=1;i<=m;i++) cout<<ans[i]<<endl;
	return 0;
}
/*
aababc
3
1 2
2 4
3 6

2
5
9
*/
