//Let's Go For IT!
#include<cstdio>
#include<cmath>
#include<algorithm>
#pragma GCC optimize("Ofast")
#define ull unsigned int
#define N 600005
namespace IO{
	inline char nc(){
		static char buf[1000000],*p=buf,*q=buf;
		return p==q&&(q=(p=buf)+fread(buf,1,1000000,stdin),p==q)?EOF:*p++;
	}
	inline int read(){
		int res = 0;
		char c = nc();
		while(c<'0'||c>'9')c=nc();
		while(c<='9'&&c>='0')res=res*10+c-'0',c=nc();
		return res;
	}
	char obuf[1<<21],*p3=obuf; 
	inline void pc(char c){ 
		p3-obuf<=(1<<20)?(*p3++=c):(fwrite(obuf,p3-obuf,1,stdout),p3=obuf,*p3++=c); 
	} 
	inline void write(ull x){ 
		if(x>9) write(x/10); 
		pc(x%10+'0'); 
	}
}
template <typename T>
struct vector
{
	int n, m;
	T *a;
	void clear() {n = 0;}
	vector() {n = m = 0, a = NULL;}
	void push_back(T x)
	{
		if (n == m)
		{
			m = m ? m << 1 : 1;
			T *b = new T[m];
			for (int i = 0; i < n; i ++ ) b[i] = a[i];
//			delete []a;
			a = b;
		}
		a[n ++ ] = x;
	}
	void resize(int x)
	{
		if (n >= x) return n = x, void();
		while (m < x) m <<= 1;
		T *b = new T[m];
		for (int i = 0; i < n; i ++ ) b[i] = a[i];
//		delete []a;
		a = b;
		n = x;
	}
	T& operator [] (int i) {return a[i];}
	int size() {return n;}
	T* begin() {return a;}
	T* end() {return a + n;}
} ;
using namespace std;
using namespace IO;
struct node{int l,r,id,dfn;}p[N];
vector<node> solid[N],erase[N],addd[N];
vector<int> minn[N];
int n,m,i,j,k,K,dep[N],nex[N],sam[N][2],len[N],fath[N],now=1,root=1,tot=1,son[N],id[N],idd[N],ls[N],rs[N],idt[N],dfn[N],dfnt,ot[N];
int z[N],ne[N],to[N],et,la[N],l,r,pos[N],idtt[N],sta[N],top,cf[N],nid[N];
ull ans[N],a[N],b[N],depp[N],qzh[N],qzh1[N],qzh2[N];
char s[N],t[N];
inline bool cmp(node a,node b){return a.dfn<b.dfn;}
inline bool cmp2(node a,node b){return a.r<b.r;}
inline void solve(int x,int y,ull &ans){
	dep[1]=1;
	for(int i=2,k=0;i<=y-x+1;i++){
		while(k&&s[x+i-1]!=s[x+k]&&x+k<=y) k=nex[k];
		if(s[x+i-1]==s[x+k]) k++;
		nex[i]=k,dep[i]=dep[k]+1;
	}
	for(int i=1;i<=y-x+1;i++) ans+=dep[i]*a[x+i-1];
}
inline void merge(int x,int y){et++,ne[et]=la[x],la[x]=et,to[et]=y;}
inline void insert(int ch){
	int p = now;len[now=(++tot)]=len[p]+1;
	while(p&&!sam[p][ch]) sam[p][ch]=now,p=fath[p];
	if(!p) fath[now]=root;
	else{
		int q = sam[p][ch];
		if(len[p]+1==len[q]) fath[now]=q;
		else{
			int temp = ++tot;
			for(int i=0;i<2;i++) sam[temp][i]=sam[q][i];
			fath[temp] = fath[q],len[temp] = len[p]+1,fath[q] = fath[now] = temp;
			while(sam[p][ch]==q) sam[p][ch]=temp,p=fath[p];
		}
	}
}
inline void dfs(int x){
	dfn[x] = ++dfnt,nid[dfn[x]] = x;
	for(int i=la[x];i;i=ne[i]) dfs(to[i]),son[x]+=son[to[i]];
	ot[x] = dfnt;
}
inline ull calc(int pos){return qzh1[idt[pos]-1]+qzh2[pos];}
inline void add(int pos,ull temp){
//	cout<<"? "<<pos<<endl;
	for(int j=idt[pos];j<=idt[tot];j++) qzh1[j]+=temp;
	for(int j=pos;j<=rs[idt[pos]];j++) qzh2[j]+=temp;
}
int main(){
	n=read(),m=read();
	K=2*sqrt(n);
	for(i=1;i<=n;i++){
		s[i]=nc();
		while(s[i]!='0'&&s[i]!='1') s[i]=nc();
	}
	for(i=1;i<=n;i++) a[i]=read(),b[i]=a[i]+b[i-1];
	for(i=1;i<=n;i++) insert(s[i]-'0'),idtt[i]=now;
	for(i=2;i<=tot;i++) merge(fath[i],i);
	dfs(1);
	for(i=1,j=1;i<=tot;i++){
		idt[i]=j;
		if(!ls[j]) ls[j]=i;
		rs[j]=i;
		if(i%K==0) j++;
	}
	//solve1-SK
	for(i=1;i<=m;i++){
		p[i].l=read(),p[i].r=read(),p[i].id=i;
		if(p[i].r-p[i].l+1<=2*K) solve(p[i].l,p[i].r,ans[i]);
		else{
			int ttot = 0;
			ans[i]+=b[p[i].r]-b[p[i].l-1];
			for(j=p[i].l;j<=rs[idt[p[i].l]];j++) t[++ttot] = s[j];
			t[ttot+1]=0,dep[1]=0;
			for(j=2,k=0;j<=ttot;j++){
				while(k&&t[j]!=t[k+1]) k=nex[k];
				if(t[j]==t[k+1]) k++;
				nex[j]=k;
				if(k) dep[j]=dep[k]+1;
				else dep[j]=0;
			}
			for(j=1;j<=ttot;j++) ans[i]+=dep[j]*a[p[i].l+j-1];
			solid[ls[idt[p[i].l]+1]].push_back(p[i]);
			erase[p[i].r+1].push_back(p[i]);
			addd[ls[idt[p[i].l]+1]].push_back(p[i]);
		}
	}
	for(i=n;i>=1;i--){
		add(dfn[idtt[i]],a[i]);
		for(j=0;j<addd[i].size();j++){
			int poss = root;
			for(k=addd[i][j].l;k<=rs[idt[addd[i][j].l]];k++){
				poss = sam[poss][s[k]-'0'];
				ans[addd[i][j].id] += calc(ot[poss])-calc(dfn[poss]-1);
			}
		}
		for(j=0;j<erase[i].size();j++){
			int poss = root;
			for(k=erase[i][j].l;k<=rs[idt[erase[i][j].l]];k++){
				poss = sam[poss][s[k]-'0'];
				ans[erase[i][j].id] -= calc(ot[poss])-calc(dfn[poss]-1);
			}
		}
	}
	//solve2-ZPL
	for(i=1;i<=n;i++){
		if(!solid[i].size()) continue;
		if(solid[i].size()<=5){
			for(j=0;j<solid[i].size();j++){
				ans[solid[i][j].id]=0;
				solve(solid[i][j].l,solid[i][j].r,ans[solid[i][j].id]);
			}
			continue;
		}
		sort(solid[i].begin(),solid[i].end(),cmp2);
		for(j=1;j<=tot;j++) qzh1[j] = qzh2[j] = 0;
		int ttot=0;
		for(j=i;j<=n;j++) t[++ttot] = s[j];
		for(j=2,k=0;j<=ttot;j++){
			while(k&&t[j]!=t[k+1]) k=nex[k];
			if(t[j]==t[k+1]) k++;
			nex[j]=k;
			if(k) depp[j]=depp[k]+1;
			else depp[j]=0;
		}
		for(j=1;j<=ttot;j++) depp[j]=depp[j-1]+depp[j]*a[j+i-1];
		for(j=0;j<solid[i].size();j++) ans[solid[i][j].id]+=depp[solid[i][j].r-i+1];
//		cout<<ans[1]<<endl;
		for(j=2,l=1,r=1;j<=ttot;j++){
			if(j+z[j-l+1]<=r) z[j]=z[j-l+1];
			else{
				z[j]=max(1,r-j+1);
				while(j+z[j]-1<=ttot&&t[z[j]]==t[j+z[j]-1]) z[j]++;
			}
			if(j+z[j]-1>r) l=j,r=j+z[j]-1;
		}
		for(j=2;j<=ttot;j++) z[j]--;
		z[1]=ttot;
//		cout<<(t+1)<<endl;
//		for(j=1;j<=ttot;j++) cout<<z[j]<<" ";
//		cout<<endl;
		for(j=1;j<=tot;j++) pos[j]=len[idtt[i-1]];
		for(j=idtt[i-1];fath[j];j=fath[j]){
			for(k=la[fath[j]];k;k=ne[k]){
				if(to[k]==j) continue;
				for(l=dfn[to[k]];l<=ot[to[k]];l++) pos[nid[l]]=len[fath[j]];
			}
		}
//		for(j=1;j<=ttot;j++) cout<<pos[idtt[i+j-2]]<<" ";
//		cout<<endl;
		for(j=0,k=i+1;j<solid[i].size();j++){
			while(k<=solid[i][j].r){
				if(z[k-i+1]==0||pos[idtt[k-1]]>K){
					for(l=0;l<minn[k].size();l++){
						qzh[minn[k][l]] += b[k];
						cf[minn[k][l]]--;
					}
					k++;
					continue;
				}
//				cout<<"!!! "<<k<<" "<<z[k-i+1]<<" "<<pos[idtt[k-1]]<<endl;
				qzh[pos[idtt[k-1]]] -= b[k-1],cf[pos[idtt[k-1]]]++;
				minn[k+z[k-i+1]-1].push_back(pos[idtt[k-1]]);
				for(l=0;l<minn[k].size();l++){
					qzh[minn[k][l]] += b[k];
					cf[minn[k][l]]--;
				}
				k++;
			}
			for(l=0;l<i-solid[i][j].l;l++) ans[solid[i][j].id]-=(qzh[l]+cf[l]*b[solid[i][j].r]);
		}
		for(j=1;j<=tot;j++) son[j]=0;
		for(j=0;j<=K;j++) qzh[j]=0,cf[j]=0;
		for(j=i+1;j<=n;j++) minn[j].clear();
	}
	for(i=1;i<=m;i++) write(ans[i]),pc('\n');
	return fwrite(obuf,p3-obuf,1,stdout),0;
}
