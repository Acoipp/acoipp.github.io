#include <bits/stdc++.h>

void play_wordle (int mode,int ACC,int FIN,std::string* acc,std::string* fin);
std::string guess (std::string str);
