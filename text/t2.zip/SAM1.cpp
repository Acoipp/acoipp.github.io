#include<bits/stdc++.h>
#pragma GCC optimize("Ofast")
#define ll int
#define N 400005
using namespace std;
struct tree{ll l,r;long long tag1,tag2;}tr[N*20];
struct node{ll l,r,c,x,tag;};
vector<node> op[N],op2[N],op3[N];
ll n,q,i,j,x,y,len[N],fath[N],sam[N][26],root=1,tot=1,now=1;
ll et,ne[N<<1],to[N<<1],la[N],dfn[N],dtot,roots[N],tr_tot,l[N],r[N];
ll st[N][21],sum[N],sons[N],top[N],id[N],leav[N],idd[N],nid[N],ROOT,cnt[N],cnt2[N],qzh[N],sta[N],edtop;
long long ans[N],tr1[N],tr2[N],tr3[N];
bool cmp(node a,node b){return dfn[a.c]<dfn[b.c];}
char s[N];
inline void merge(ll x,ll y){et++,ne[et]=la[x],la[x]=et,to[et]=y;}
inline void insert(ll x){
	ll p = now;now = ++tot,len[now] = len[p]+1;
	while(p&&!sam[p][x]) sam[p][x]=now,p=fath[p];
	if(!p) fath[now]=root;
	else{
		ll q = sam[p][x];
		if(len[p]+1==len[q]) fath[now]=q;
		else{
			ll temp = ++tot;
			for(ll i=0;i<26;i++) sam[temp][i]=sam[q][i];
			fath[temp] = fath[q],len[temp] = len[p]+1,fath[q] = fath[now] = temp;
			while(p&&sam[p][x]==q) sam[p][x]=temp,p=fath[p];
		}
	}
}
inline void pushtag(ll p,long long c1,long long c2){tr[p].tag1 += c1,tr[p].tag2 += c2;}
inline void pushdown(ll p){
	if(tr[p].l) pushtag(tr[p].l,tr[p].tag1,tr[p].tag2);
	if(tr[p].r) pushtag(tr[p].r,tr[p].tag1,tr[p].tag2);
	tr[p].tag1 = tr[p].tag2 = 0;
}
inline void add(ll x,ll s,ll t,ll &p){
	if(!p) p=++tr_tot,tr[p].l=tr[p].r=tr[p].tag1=tr[p].tag2=0;
	if(s==t) return ;
	if(tr[p].tag1||tr[p].tag2) pushdown(p);
	if(x<=(s+t)/2) add(x,s,(s+t)/2,tr[p].l);
	else add(x,(s+t)/2+1,t,tr[p].r);
}
inline void init(ll x){
	sum[x]=1;
	for(ll i=1;i<=20;i++) st[x][i]=st[st[x][i-1]][i-1];
	for(ll i=la[x];i;i=ne[i]){
		st[to[i]][0]=x,init(to[i]);
		if(sum[to[i]]>sum[sons[x]]) sons[x]=to[i];
		sum[x]+=sum[to[i]];
	}
}
inline void init2(ll x,ll topp){
	dfn[x] = ++dtot,nid[dtot] = x,top[x] = topp;
	if(sons[x]) init2(sons[x],topp),leav[x]=leav[sons[x]];
	else leav[x]=x;
	for(ll i=la[x];i;i=ne[i]){
		if(to[i]==sons[x]) continue;
		init2(to[i],to[i]);
	}
}
inline void modify(ll l,ll r,ll c1,ll c2,ll s,ll t,ll p){
	if(!p||l>r) return ;
	if(l<=s&&t<=r) return pushtag(p,c1,c2);
	if(tr[p].tag1||tr[p].tag2) pushdown(p);
	if(l<=(s+t)/2) modify(l,r,c1,c2,s,(s+t)/2,tr[p].l);
	if(r>(s+t)/2) modify(l,r,c1,c2,(s+t)/2+1,t,tr[p].r);
}
inline long long query(ll x,ll s,ll t,ll p){
	if(s==t) return tr[p].tag1+tr[p].tag2*qzh[s];
	if(tr[p].tag1||tr[p].tag2) pushdown(p);
	if(x<=(s+t)/2) return query(x,s,(s+t)/2,tr[p].l);
	else return query(x,(s+t)/2+1,t,tr[p].r);
}
inline ll solve(ll l,ll r,ll pos,ll id,ll idd){
	while(pos){
//		cout<<"!! "<<pos<<endl;
		op[top[pos]].push_back((node){l,r,pos,id,idd});
		if(fath[top[pos]]) op2[top[pos]].push_back((node){l,r,pos,id,idd});
		op3[pos].push_back((node){l,r,pos,id,idd});
		pos = fath[top[pos]]; 
	}
	return 0;
}
inline void add(ll k,ll len){sta[++edtop]=k;ll x=k;while(k<=n) tr1[k]+=x,tr2[k]++,tr3[k]+=len,k+=k&(-k);}
inline long long query1(ll k){
	long long num = 0;
	while(k) num+=tr1[k],k-=k&(-k);
	return num;
}
inline long long query2(ll k){
	long long num = 0;
	while(k) num+=tr2[k],k-=k&(-k);
	return num;
}
inline long long query3(ll k){
	long long num = 0;
	while(k) num+=tr3[k],k-=k&(-k);
	return num;
}
inline void clear(){
	while(edtop){
		ll k = sta[edtop--];
		while(k<=n) tr1[k]=0,tr2[k]=0,tr3[k]=0,k+=k&(-k);
	}
}
inline void get_res(ll x,ll c){
	if(idd[x]){
		ll pos = idd[x]-c+1<0?0:cnt[idd[x]-c+1];
		modify(pos+1,q,idd[x]+1,-1,1,q,ROOT);
		modify(1,pos,c,0,1,q,ROOT);
		add(idd[x],c);
	}
	for(ll i=la[x];i;i=ne[i]) get_res(to[i],c);
}
inline void solve(ll x){
	if(x==top[x]){
		sort(op[x].begin(),op[x].end(),cmp);
		for(i=0;i<op[x].size();i++) add(op[x][i].tag,1,q,ROOT);
		for(ll i=dfn[x],j=0;i<=dfn[leav[x]];i++){
			while(j<op[x].size()&&dfn[op[x][j].c]==i){
				ans[op[x][j].x] -= (query1(op[x][j].l-1)-query2(op[x][j].l-1)*(op[x][j].l-1));
				ans[op[x][j].x] -= query3(n)-query3(op[x][j].r);
				ans[op[x][j].x] += query(op[x][j].tag,1,q,ROOT);
				j++;
			}
			ll pos = nid[i];
			if(idd[pos]){
				ll poss = idd[pos]-len[pos]+1<0?0:cnt[idd[pos]-len[pos]+1];
				modify(poss+1,q,idd[pos]+1,-1,1,q,ROOT);
				modify(1,poss,len[pos],0,1,q,ROOT);
				add(idd[pos],len[pos]);
			}
			for(ll j=la[pos];j;j=ne[j]){
				if(to[j]==sons[pos]) continue;
				get_res(to[j],len[pos]);
			}
		}
		ROOT=0,tr_tot=0,clear();
	}
	for(ll i=la[x];i;i=ne[i]) solve(to[i]);
}
inline ll merge3(ll s,ll t,ll p1,ll p2){
	if(!p1||!p2) return p1+p2;
	tr[p1].l = merge3(s,(s+t)/2,tr[p1].l,tr[p2].l);
	tr[p1].r = merge3((s+t)/2+1,t,tr[p1].r,tr[p2].r);
	tr[p1].tag1 = tr[tr[p1].l].tag1 + tr[tr[p1].r].tag1;
	tr[p1].tag2 = tr[tr[p1].l].tag2 + tr[tr[p1].r].tag2;
	return p1;
}
inline void add3(ll x,ll c1,ll c2,ll s,ll t,ll &p){
	if(!p) p=++tr_tot,tr[p].l=tr[p].r=tr[p].tag1=tr[p].tag2=0;
	if(s==t){
		tr[p].tag1+=c1,tr[p].tag2+=c2;
		return ;
	}
	if(x<=(s+t)/2) add3(x,c1,c2,s,(s+t)/2,tr[p].l);
	else add3(x,c1,c2,(s+t)/2+1,t,tr[p].r);
	tr[p].tag1 = tr[tr[p].l].tag1 + tr[tr[p].r].tag1;
	tr[p].tag2 = tr[tr[p].l].tag2 + tr[tr[p].r].tag2;
}
inline long long query(ll l,ll r,ll c,ll s,ll t,ll p){
	if(!p||l>r) return 0;
	if(l<=s&&t<=r) return c==1?tr[p].tag1:tr[p].tag2;
	long long ans = 0;
	if(l<=(s+t)/2) ans+=query(l,r,c,s,(s+t)/2,tr[p].l);
	if(r>(s+t)/2) ans+=query(l,r,c,(s+t)/2+1,t,tr[p].r);
	return ans;
}
inline void solve2(ll x){
	for(ll i=la[x];i;i=ne[i]) solve2(to[i]),roots[x]=merge3(1,n,roots[x],roots[to[i]]);
	if(idd[x]) add3(idd[x],idd[x],1,1,n,roots[x]);
	for(ll i=0;i<op2[x].size();i++){
		long long res = 0;
		res += query(op2[x][i].l,op2[x][i].l+len[fath[x]]-1,1,1,n,roots[x]);
		res -= query(op2[x][i].l,op2[x][i].l+len[fath[x]]-1,2,1,n,roots[x])*(op2[x][i].l-1);
		res += query(op2[x][i].l+len[fath[x]],op2[x][i].r,2,1,n,roots[x])*len[fath[x]];
		ans[op2[x][i].x]-=res;
	}
	for(ll i=0;i<op3[x].size();i++){
		long long res = 0;
		res += query(op3[x][i].l,op3[x][i].l+len[x]-1,1,1,n,roots[x]);
		res -= query(op3[x][i].l,op3[x][i].l+len[x]-1,2,1,n,roots[x])*(op3[x][i].l-1);
		res += query(op3[x][i].l+len[x],op3[x][i].r,2,1,n,roots[x])*len[x];
		ans[op3[x][i].x]+=res;
	}
}
namespace IO{
	inline char nc(){
		static char buf[1000000],*p=buf,*q=buf;
		return p==q&&(q=(p=buf)+fread(buf,1,1000000,stdin),p==q)?EOF:*p++;
	}
	inline ll read(){
		ll res = 0,w = 1;
		char c = nc();
		while(c<'0'||c>'9')w=(c=='-'?-1:w),c=nc();
		while(c<='9'&&c>='0')res=res*10+c-'0',c=nc();
		return res*w;
	}
	char obuf[1<<21],*p34=obuf; 
	inline void pc(char c){ 
		p34-obuf<=(1<<20)?(*p34++=c):(fwrite(obuf,p34-obuf,1,stdout),p34=obuf,*p34++=c); 
	} 
	inline void write(long long x){ 
		if(x>9) write(x/10); 
		pc(x%10+'0'); 
	}
}
using namespace IO;
int main(){
//	freopen("1.in","r",stdin);
//	freopen("1.out","w",stdout);
	char ch = nc();
	while('a'<=ch&&ch<='z') s[++n]=ch,ch=nc();
	q=read();
	reverse(s+1,s+n+1);
	for(i=1;i<=n;i++) insert(s[i]-'a'),id[i]=now,idd[now]=i;
	for(i=2;i<=tot;i++) merge(fath[i],i);
	for(i=1;i<=q;i++) l[i]=read(),r[i]=read(),swap(l[i],r[i]),l[i]=n-l[i]+1,r[i]=n-r[i]+1,cnt[l[i]]++,qzh[i]=l[i];
	sort(qzh+1,qzh+q+1);
	for(i=1;i<=2*n;i++) cnt[i]+=cnt[i-1],cnt2[i]=cnt[i];
	init(1);
	init2(1,1);
	for(i=1;i<=q;i++){
		ll pos = id[r[i]];
		for(j=20;j>=0;j--) if(st[pos][j]&&len[fath[st[pos][j]]]>=r[i]-l[i]+1) pos=st[pos][j];
		if(len[fath[pos]]>=r[i]-l[i]+1) pos=fath[pos];
		solve(l[i],r[i],pos,i,cnt2[l[i]]--);
	}
	solve(1);
	solve2(1);
	for(i=1;i<=q;i++) write(ans[i]),pc('\n');
	fwrite(obuf,p34-obuf,1,stdout);
	return 0;
}
