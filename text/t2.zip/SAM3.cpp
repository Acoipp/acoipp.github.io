//Let's Go For IT!
#include<cstdio>
#include<vector>
#include<climits>
#include<algorithm>
#include<cmath>
#include<cassert>
#pragma GCC optimize("Ofast")
#define ll long long
#define N 1000005
#define M 800005
#define Q 400005
using namespace std;
namespace IO{
	inline char nc(){
		static char buf[1000000],*p=buf,*q=buf;
		return p==q&&(q=(p=buf)+fread(buf,1,1000000,stdin),p==q)?EOF:*p++;
	}
	inline int read(){
		int res = 0,w = 1;
		char c = nc();
		while(c<'0'||c>'9')w=(c=='-'?-1:w),c=nc();
		while(c<='9'&&c>='0')res=res*10+c-'0',c=nc();
		return res*w;
	}
	char obuf[1<<21],*p34=obuf; 
	inline void pc(char c){ 
		p34-obuf<=(1<<20)?(*p34++=c):(fwrite(obuf,p34-obuf,1,stdout),p34=obuf,*p34++=c); 
	} 
	inline void write(ll x){ 
		if(x>9) write(x/10); 
		pc(x%10+'0'); 
	}
}
using namespace IO;
int n,a,b,l[N],r[N],i,G,LOG[N],pl[Q],pr[Q];
ll ans[N];
char s[N];
struct BIT{
	int sta[N],top;
	ll tr[N];
	inline void add(int k,int x){sta[++top]=k;while(k<=n) tr[k]+=x,k+=k&(-k);}
	inline ll query(int k){
		ll num = 0;
		while(k) num+=tr[k],k-=k&(-k);
		return num;
	}
	inline void clear(){
		for(int i=1;i<=top;i++){
			int k = sta[i];
			while(k<=n) tr[k]=0,k+=k&(-k);
		}
		top=0;
	}
}bit;
struct sam{
	int sam[N][26],fath[N],len[N],root=1,tot=1,now=1,et,ne[N],la[N],to[N],st[N][21],id[N],sonlist[N],dep[N],dfn[N],dfnt;
	int bgpos[N],edpos[N],col[N];
	inline void merge(int x,int y){et++,ne[et]=la[x],la[x]=et,to[et]=y;}
	inline void insert(int ch,int idd){
		int p = now;len[now=(++tot)]=len[p]+1,id[idd] = now,bgpos[now]=idd,edpos[now]=idd;
		while(p&&!sam[p][ch]) sam[p][ch]=now,p=fath[p];
		if(!p) fath[now]=root;
		else{
			int q = sam[p][ch];
			if(len[p]+1==len[q]) fath[now]=q;
			else{
				int temp = ++tot;
				for(int i=0;i<26;i++) sam[temp][i]=sam[q][i];
				fath[temp] = fath[q],len[temp] = len[p]+1,fath[q] = fath[now] = temp;
				while(sam[p][ch]==q) sam[p][ch]=temp,p=fath[p];
			}
		}
	}
	inline void dfs(int x){
		dfn[++dfnt] = x;
		for(int i=1;i<=LOG[dep[x]];i++) st[x][i]=st[st[x][i-1]][i-1];
		for(int i=la[x];i;i=ne[i]){
			st[to[i]][0] = x;
			dep[to[i]] = dep[x]+1;
			dfs(to[i]);
			edpos[x] = max(edpos[x],edpos[to[i]]);
			if(!bgpos[x]) bgpos[x]=bgpos[to[i]];
			else bgpos[x]=min(bgpos[x],bgpos[to[i]]);
		}
	}
	inline void solve(){
		for(int i=2;i<=tot;i++) sonlist[dfn[i]]+=sonlist[fath[dfn[i]]];
	}
	inline void build_fail(){
		for(int i=2;i<=tot;i++) merge(fath[i],i);
		dep[1]=1,dfs(1);
	}
	inline int found_pos(int l,int r,int type){
		int pos = (type==1?id[r]:id[n-r+1]);
		for(int i=LOG[dep[pos]];i>=0;i--) if(len[st[pos][i]]>=r-l+1) pos=st[pos][i];
		return pos;
	}
}sam1,sam2;
int lx[N],rx[N],ly[N],ry[N],vis[N],righttail[N];
inline void build_basis(){
	for(int x=2;x<=sam1.tot;x++){
		int ls = sam1.edpos[x]-sam1.len[x]+1,rs = sam1.edpos[x];
		swap(ls,rs),ls=n-ls+1,rs=n-rs+1;
		int pos = sam2.found_pos(ls,rs,-1);
//		printf("! %d %d %d\n",n-rs+1,n-ls+1,pos);
		if(!sam2.col[pos]) sam2.col[pos] = ++G;
		sam1.col[x] = sam2.col[pos];
	}
}
inline void build_basis2(){
	for(int x=1;x<=sam2.tot;x++){
		int ls = sam2.edpos[x],rs = sam2.edpos[x]+sam2.len[x]-1;
		int pos = sam1.found_pos(ls,rs,1);
		sam2.col[x] = sam1.col[pos];
	}
}
struct paii{int a,b;};
vector<paii> opx[N];
vector<paii> opy[N];
paii func[N];
inline void build_basis3(){
	for(int x=1;x<=sam1.tot;x++){
		ly[sam1.col[x]] = min(ly[sam1.col[x]],sam1.bgpos[x]);
		ry[sam1.col[x]] = max(ry[sam1.col[x]],sam1.bgpos[x]);
		opy[sam1.col[x]].emplace_back((paii){sam1.bgpos[x],sam1.sonlist[sam1.fath[x]]});
	}
}
inline void build_basis4(){
	for(int x=1;x<=sam2.tot;x++){
		lx[sam2.col[x]] = min(lx[sam2.col[x]],sam2.bgpos[x]);
		rx[sam2.col[x]] = max(rx[sam2.col[x]],sam2.bgpos[x]);
	//	printf("dx %d %d\n",sam2.col[x],sam2.bgpos[x]);
		opx[sam2.col[x]].emplace_back((paii){sam2.bgpos[x],sam2.sonlist[sam2.fath[x]]});
	}
}
inline void build_basis5(){
	for(int x=1;x<=sam1.tot;x++) if(ry[sam1.col[x]]==sam1.bgpos[x]) righttail[sam1.col[x]] = sam1.col[sam1.fath[x]];
}
struct nodee{int l,r,x;};
vector<nodee> task1[N];
vector<ll> under[N],right[N]; 
int j,real[N],rear[N],pos[N],maxl[N],maxr[N];
ll son[N];
inline bool cmp(nodee a,nodee b){
	if(a.l!=b.l) return a.l>b.l;
	return a.x<b.x;
}
inline void solve1(){
	for(int i=1;i<=G;i++){
		sort(task1[i].begin(),task1[i].end(),cmp);
		for(int j=0;j<task1[i].size();j++){
			if(task1[i][j].x==-1) bit.add(task1[i][j].r,1);
			else ans[task1[i][j].x] += bit.query(task1[i][j].r);
		}
		bit.clear();
	}
}
inline void solve2(){
	for(int i=1;i<=b;i++) ans[i] += under[sam1.col[pos[i]]][real[i]-lx[sam1.col[pos[i]]]+1];
}
inline void solve3(){
	for(int i=1;i<=b;i++) ans[i] -= right[sam1.col[pos[i]]][rear[i]-ly[sam1.col[pos[i]]]+2];
}
inline void solve4(){
	for(int i=1;i<=b;i++) ans[i] += son[righttail[sam1.col[pos[i]]]];
}
inline void print(){
	for(i=1;i<=b;i++) write(ans[i]),pc('\n');
	fwrite(obuf,p34-obuf,1,stdout);
}
int cur,cir[N];
int main(){
	for(i=1,n=0;i*2-1<=1e6;i*=2,n++) for(j=i;j<=i*2-1;j++) LOG[j]=n;
	n=read(),a=read(),b=read();
	for(i=1;i<=n;i++){
		s[i]=nc();
		while(s[i]<'a'||s[i]>'z') s[i]=nc();
	}
	for(i=1;i<=n;i++) sam1.insert(s[i]-'a',i);
	for(i=n;i>=1;i--) sam2.insert(s[i]-'a',i);
	sam1.build_fail(),sam2.build_fail();
	for(i=1;i<=a;i++) l[i]=read(),r[i]=read(),sam1.sonlist[sam1.found_pos(l[i],r[i],1)]++,sam2.sonlist[sam2.found_pos(n-r[i]+1,n-l[i]+1,-1)]++;
	for(i=1;i<=b;i++) pl[i]=read(),pr[i]=read();
	sam1.solve(),sam2.solve();
	//build on the basis
	build_basis();
	build_basis2();
	for(i=1;i<=G;i++) lx[i]=ly[i]=INT_MAX;
	build_basis3();
	build_basis4();
	build_basis5();
	//task1--in G
	for(i=1;i<=a;i++){
		int pos = sam1.found_pos(l[i],r[i],1);
		int real = sam1.bgpos[pos]-(r[i]-l[i]+1)+1,rear = sam1.bgpos[pos];
		son[sam1.col[pos]]++;
		task1[sam1.col[pos]].emplace_back((nodee){real,rear,-1});
//		printf("## %d\n",sam1.col[pos]);
	}
	for(i=1;i<=b;i++){
		pos[i] = sam1.found_pos(pl[i],pr[i],1);
		real[i] = sam1.bgpos[pos[i]]-(pr[i]-pl[i]+1)+1,rear[i] = sam1.bgpos[pos[i]];
		task1[sam1.col[pos[i]]].emplace_back((nodee){real[i],rear[i],i});
//		printf("### %d\n",sam1.col[pos[i]]);
	}	
	solve1();
	//task2--under G+task3--right G
	for(i=1;i<=G;i++){
		under[i].emplace_back(0),right[i].emplace_back(0);
		int ls = INT_MAX,rs = INT_MIN;
		for(j=0;j<opx[i].size();j++) func[opx[i][j].a]=opx[i][j],ls=min(ls,opx[i][j].a),rs=max(rs,opx[i][j].a);
		opx[i].clear();
		for(j=ls;j<=rs;j++) opx[i].emplace_back(func[j]);
		ls = INT_MAX,rs = INT_MIN;
		for(j=0;j<opy[i].size();j++) func[opy[i][j].a]=opy[i][j],ls=min(ls,opy[i][j].a),rs=max(rs,opy[i][j].a);
		opy[i].clear();
		for(j=ls;j<=rs;j++) opy[i].emplace_back(func[j]);
	}
	for(i=1;i<=G;i++){
//		printf("# %d\n",i);
		for(j=0;j<opx[i].size();j++) under[i].emplace_back(opx[i][j].b)/*,printf("%lld ",opx[i][j].b)*/;
//		printf("\n");
		for(j=0;j<opy[i].size();j++) right[i].emplace_back(opy[i][j].b)/*,printf("%lld ",opy[i][j].b)*/;
//		printf("\n");
		under[i].emplace_back(0);
		right[i].emplace_back(0);
		for(j=under[i].size()-1;j>=1;j--) under[i][j-1]+=under[i][j];
		for(j=right[i].size()-1;j>=1;j--) right[i][j-1]+=right[i][j];
		son[i]+=under[i][0];
//		printf("### %d %d\n",i,son[i]);
	}	
	for(i=1;i<=G;i++){
		if(!vis[i]){
			cur=0;
			for(j=i;;j=righttail[j]){
				cir[++cur] = j;
				if(vis[j]) break;
				vis[j]=1;
			}
			for(j=cur-1;j>=1;j--) son[cir[j]]+=son[cir[j+1]];
		}
//		printf("righttail %d %d %d\n",i,righttail[i],son[i]);
	}
	solve2();	
	solve3();		
	//task4--right G'
	solve4();
	print();
	return 0;
}
